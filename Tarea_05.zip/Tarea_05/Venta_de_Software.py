#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Venta de software
#Aqui calculamos el descuento dependiendo de lo que nos hayan dado.
def CalcularPaquetesSoftwareConDescuento(Paquetes_s):
    if Paquetes_s == 10 or Paquetes_s <= 19 :
        c = Paquetes_s * 1500
        Total = c - (c * .2)
        return Total
    elif Paquetes_s == 20 or Paquetes_s <= 49 :
        c = Paquetes_s * 1500
        Total = c - (c * .3)
        return Total
    elif Paquetes_s == 50 or Paquetes_s <= 99 :
        c = Paquetes_s * 1500
        Total = c - (c * .4)
        return Total
    elif Paquetes_s >= 100 :
        c = Paquetes_s * 1500
        Total = c - (c * .5)
        
#Definimos lo paquetes que se compran y  
def main():
    Paquetes_s = int(input("¿Cuántos paquetes desea llevar señor?"))
    if Paquetes_s == 9 or Paquetes_s < 9 :
        c = Paquetes_s * 1500
        print("No pues paganos sin descuento amigo :v, serían: $",c)
    elif Paquetes_s < 1 :
        print("Ese valor no existe en esta tienda :/")
    else :
        Total = CalcularPaquetesSoftwareConDescuento(Paquetes_s)
        print ("El total a pagar con todo y descuento es de: $",Total)
main()