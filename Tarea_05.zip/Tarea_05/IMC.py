#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Índice de Masa Corporal

#Aquí se calcula el índice de masa corporal.
def CalcularElIMC(Masa,Altura):
    IMC = Masa/(Altura**2)
    return IMC
#Definimos la altura y el peso de la persona
def main():
    Masa = int(input("¿Cuánto pesas?"))
    Altura = float(input("¿Qué tan alto eres?"))
    if Altura <= 0 and Masa <=0 :
        print("No existes entonces :v")
    else :
        IMC = CalcularElIMC(Masa,Altura)
        if IMC < 18.5 :
            print ("Tienes un IMC de",IMC,"eso se define cómo un bajo peso")
        elif IMC > 18.5 or IMC == 25 :
            print ("Tienes un IMC de",IMC,", eso se define cómo un peso normal")
        elif IMC > 25 :
            print ("Tienes un IMC de",IMC,", eso se define cómo un sobrepeso")
main()