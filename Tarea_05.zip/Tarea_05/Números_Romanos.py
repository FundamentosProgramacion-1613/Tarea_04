#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Números arabicos a números romanos

#Aqui se transformara el numero
def TransformarNúmeroArábicoARomano(Num):
    if Num == 1 or Num <=3 :
        #Rom es el Número Romano
        Rom = Num * 'I'
        return Rom
    elif Num == 4 :
        #Este solo nos ayuda a saber si es 4 :v
        Rom = 'IV'
        return Rom
    elif Num == 5 or Num <= 8:
        #Rom2 nos dira si tiene mas de5 o no
        Rom2 = (Num - 5) * 'I'
        Rom = 'V' + Rom2
        return Rom
    elif Num >= 9 or Num <= 10:
        #Rom3 definira si es 10 o es 9
        Rom3 = (10 - Num)* 'I'
        Rom = Rom3 + 'X'
        return Rom

#Definimos nuestras funciones y variables
def main():
    Num = int(input("Dime que número vas a usar"))
    Rom = TransformarNúmeroArábicoARomano(Num)
    if Num <1 or Num >10 :
        print("No puedo hacer esta acción")
    else:
        print (Rom)
main()