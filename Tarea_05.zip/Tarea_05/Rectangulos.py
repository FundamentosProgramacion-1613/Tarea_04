#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Areas de rectangulos 

#Aqui sacamos el area del primer recangulo
def SacandoElPrimerArea(Base1,Altura1):
    Area1 = Base1*Altura1
    return Area1
#Aqui sacamos el perímetro del primer rectangulo
def SacandoElPrimerPerímetro(Base1,Altura1):
    Perímetro1 = (2*Base1)+(2*Altura1)
    return Perímetro1
#Aquí sacamos el area del segundo rectangulo
def SacandoLaSegundaArea(Base2,Altura2):
    Area2 = Base2*Altura2
    return Area2
#Aquí sacamos el perímetro del segundo rectangulo
def SacandoElSegundoPerímetro(Base2,Altura2):
    Perímetro2 = (2*Base2)+(2*Altura2)
    return Perímetro2
#Definimos variables y funciones
def main():
    Base1 = int(input("Dame la primera base"))
    Altura1 = int(input("Dame la primera altura"))
    Base2 = int(input("Dame la segunda base"))
    Altura2 = int(input("Dame la segunda altura"))
    Area1 = SacandoElPrimerArea(Base1,Altura1)
    Area2 = SacandoLaSegundaArea(Base2,Altura2)
    Perímetro1 = SacandoElPrimerPerímetro(Base1,Altura1)
    Perímetro2 = SacandoElSegundoPerímetro(Base2,Altura2)
    print(Area1)
    print(Perímetro1)
    print(Area2)
    print(Perímetro2)
    if Area1 == Area2 :
        print("Las areas de los rectangulos son iguales")
    elif Area1 > Area2 :
        print("El area del primer rectangulo es mayor a la del segundo")
    else :
        print("El area del segundo rectangulo es mayor a la del primero")
    if Perímetro1==Perímetro2 :
        print("Los perímetros de los rectangulos son iguales")
    elif perímetro1 > perímetro2 :
        print("El perímetro del primer rectangulo esmayor a la del segundo")
    else :
        print("El perímetro del segundo rectangulo es mayor a la del primer")
main()