#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Conbinaciones de colores

#Aqui hacemos las operaciones para obtener el color
def CombinacionDeColores(a,b):
    c = a+b
    if c == 3 and a == 1 and b == 2 or a == 2 and b == 1 :
        Combinado = 'Morado'
        return Combinado
    elif c == 4 and a == 3 and b == 1 or a == 1 and b == 3:
        Combinado = 'Naranja'
        return Combinado
    elif c == 5 and a == 2 and b == 3 or a == 3 and b == 2:
        Combinado = 'Verde'
        return Combinado

#Aqui definimos nuestros colores y la funcion que nos ayudara a combinarlos
def main():
    print("1.-Rojo")
    print("2.-Azul")
    print("3.-Amarillo")
    a = int(input("Dame el primer color que quieres combinar"))
    b = int(input("Dame el segundo color que quieres combinar"))
    if a>3 and b>3 or a<1 and b < 1:
        print("No existe ese color :v")
    elif a==b :
        print("Tus colores son iguales, por lo tanto, te da el mismo color")
    else:
        Combinado = CombinacionDeColores(a,b)
        print(Combinado)
main()