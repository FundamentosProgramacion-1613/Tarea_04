#encoding: UTF-8
#Author: Héctor David Hernández Rodríguez
#IMC

def calcularTotal(P):
    if P>=10 and P<=19:
        D=1500*.2
        pt=(P*1500)-D
    elif P>=20 and P<=49:
        D=1500*.3
        pt=(P*1500)-D
    elif P>=50 and P<=99:
        D=1500*.4
        pt=(P*1500)-D
    elif P>100:
        D=1500*.5
        pt=(P*1500)-D
        
    return pt

def main():
    P=int(input("Introduce el numero e paquetes"))
    if P<=0:
        print("ERROR")
    else:
        calcularTotal()
        print ("El Precio Total es",pt)
main()