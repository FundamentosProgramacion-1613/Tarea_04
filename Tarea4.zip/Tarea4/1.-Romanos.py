#encoding: UTF-8
#Author:Héctor David Hernández Rodríguez
#Numeros Romanos


def calcularNumero(n):
    if n==1:
        print("I")
    elif n==2:
        print("II")
    elif n==3:
        print("III")
    elif  n==4:
        print("IV")
    elif n==5:
        print("V")
    elif n==6:
        print("VI")
    elif n==7:
        print("VII")
    elif n==8:
        print("VIII")
    elif n==9:
        print("IX")
    else:
        print("X")

def main ():
    n = int(input("introducee un numero del 1-10"))
    if n<=0 or n>=11:
        print ("ERROR")
        print("Escoja un numero en el rango 1-10, Por favor")
    else:
        calcularNumero(n)
main()