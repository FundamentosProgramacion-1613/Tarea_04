#encoding: UTF-8
#Author: Hector David Hernndez Rodriguez
#IMC

def calcularIndice(peso,estatura):
    IMC = peso/(estatura*estatura)
    return IMC
def determinaIndice(IMC):
    if IMC < 18.5:
        TP = "bajo peso"
        
    elif IMC > 18.5 and IMC < 25:
        TP = "peso normal"
        
    elif IMC > 25:
        TP = "sobrepeso"
        
    return TP
def main():
    P = float(input("Ingrese peso en Kg"))
    E = float(input("Ingrese estatura en mts."))
            
    if P > 0 and E > 0 :
        IMC = calcularIndice(P,E)
        TP = determinaIndice(IMC)
        print("Su indice es",TP)
        IMC = round(IMC,(2))
        print("Su peso es ",IMC)
        
    
    else :
        print("ERROR")
        
    
main()